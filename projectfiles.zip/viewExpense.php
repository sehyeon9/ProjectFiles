<?php 
    include 'dbConnection.php';
    include 'LoginBackend.php';
    session_start();
    $userID = $_SESSION['id'];
    if (isset($_POST["output"])) {
        // print "Average or Total: " . $_POST["decision"];
        // print "; Day, Month, Year: " . $_POST["list"];
        // print "; specific date: " . $_POST["subList"] . "; ";
        $decision = $_POST["decision"];
        $list = $_POST["list"];
        $subList = $_POST["subList"];
    if ($decision != "Choose one" && $list != "Choose one" && $subList != 0) {
        if ($list == "Month") {
            if ($subList < 10) { //start month is 1 - 8 and end date is 2 - 9
                $startDate = "2019-0" . $subList . "-01";
                $endDate = "2019-0" . $subList . "-30";
            } else if ($subList == 9) { //start month is 9 end month is 10
                $startDate = "2019-09-01";
                $endDate = "2019-9-30";
            }
            else if ($subList > 9 && $subList < 12) { //Month is 10 or 11 so that end date is 11 or 12
                $startDate = "2019-" . $subList . "-01";
                $endDate = "2019-" . $subList . "-30";
            } 
            else { //start month is 12 so end month is 1
                $startDate = "2019-" . $subList . "-01";
                $endDate = "2019-". $subList . "-30";
            }
        }
        //print " Start date: " . $startDate . ";";
        //print " End date: " . $endDate . ";";
        if ($decision == "Average") {
            $getUserAvgExpense = "SELECT AVG(money_spent) AS avg_sum FROM categories WHERE id='$userID' AND curr_date BETWEEN CAST('$startDate' AS DATE) AND CAST('$endDate' AS DATE)";
            $getAvgExp = mysqli_query($database, $getUserAvgExpense);
            $avgExpArr = mysqli_fetch_assoc($getAvgExp);
            $avgExp = $avgExpArr['avg_sum'];
            $expense = money_format('%.2n', $avgExp);
            //print " Average sum: " . $expense . ";";
        } else {
            $getUserTotExpense = "SELECT SUM(money_spent) AS tot_sum FROM categories WHERE id='$userID' AND curr_date BETWEEN CAST('$startDate' AS DATE) AND CAST('$endDate' AS DATE)";
            $getTotExp = mysqli_query($database, $getUserTotExpense);
            $totExpArr = mysqli_fetch_assoc($getTotExp);
            $totExp = $totExpArr['tot_sum'];
            $expense = money_format('%.2n', $totExp);
            //print " Total sum: " . $expense . ";";
        }
    }
    else {
        print "One or more of the fields is missing";
    }
}

    if (isset($_POST["compare"])) {
        if (isset($_POST['first_date']) && isset($_POST['second_date'])) {
            $firstDate = $_POST['first_date'];
            $secondDate = $_POST['second_date'];
            $findFirstDate = "SELECT SUM(money_spent) AS total_money_spent FROM categories WHERE id='$userID' AND curr_date='$firstDate'";
            $firstDateArr = mysqli_fetch_assoc(mysqli_query($database, $findFirstDate));
            //for first date
            if (mysqli_num_rows(mysqli_query($database, $findFirstDate)) != 0) {
                $firstDateExpense = $firstDateArr['total_money_spent'];
                //for second date
                $findSecondDate = "SELECT SUM(money_spent) AS tot_money_spent FROM categories WHERE id='$userID' AND curr_date='$secondDate'";
                $secondDateArr = mysqli_fetch_assoc(mysqli_query($database, $findSecondDate));
                if (mysqli_num_rows(mysqli_query($database, $findSecondDate)) != 0) {
                    $secondDateExpense = $secondDateArr['tot_money_spent'];
                } else {
                    print "Second date does not exist for user";
                }
            } else {
                print "First date does not exist for user";
            }
        } else {
            print "Missing a date";
        }
    }

?>

<!DOCTYPE html>
<html>
    <head>
        <title>View and Compare Expense</title>
        <link rel="stylesheet" href="Login.css">
    </head>

    <body onload="dropdown()">

        <script src="viewExpense.js"></script>
        <form action="viewExpense.php" method="POST">

            <h2>View Expense</h2>
            <select id="decision" name="decision">
                <option name="notSelected" value="default" selected>Choose one</option>
                <option name="avg" value="Average">Average</option>
                <option name="tot" value="Total">Total</option>
            </select>
            <select id="average" name="list" onchange="dropdown()">
                <option name="default" value="default" selected>Choose one</option>
                <option name="day" value="Day">Day</option>
                <option name="month" value="Month">Month</option>
                <option name="year" value="Year">Year</option>
            </select>

            <select id="subSelect" name="subList" value="---">
                <option value="---">Choose one</option>
            </select>
            <input type="submit" name="output" value="Get">
            <br/>
            $<input type="text" value="<?php print $expense ?>" placeholder="0.00" readonly>
            <br/>

            <h3>Compare Total Expense Between Two Days</h3>
            <input type="date" name="first_date">
            <input type="date" name="second_date">
            <input type="submit" name="compare" value="Compare">
            <br/>
            $<input type="text" value="<?php print $firstDateExpense ?>" readonly>
            $<input type="text" value="<?php print $secondDateExpense ?>" readonly>

            <br/>
            <a href="home.php">Home</a>
            <br/>
            <a href="logout.php">Log out</a>

        </form>

    </body>
</html>